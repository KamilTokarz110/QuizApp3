package com.example.quizapp.chooser

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.quizapp.R
import kotlinx.android.synthetic.main.fragment_profile.view.*
import kotlinx.android.synthetic.main.fragment_quizitem_list.*
//import com.example.quizapp.chooser.layoutManager as layoutManager

//private var View.adapter: QuizChooserRecyclerViewAdapter?
//    get() = null
//    set(value) = TODO()

//private var View.layoutManager: GridLayoutManager?
//get()= null
//set(value)= TODO()


class QuizChooserFragment : Fragment() {

    private lateinit var onStartQuizListener: OnStartQuizListener

    private val quizzesMap: HashMap<String, QuizItem> = HashMap()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if(context is OnStartQuizListener){
            onStartQuizListener = context
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_quizitem_list, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setUpRecyclerView()
        //TODO doimplementować makiety
        setCommunication()
    }

    private fun setCommunication() {
        quizzesMap.apply {
            put("23", QuizItem())
            put("231",QuizItem(lang = LangEnum.JAVA))
            put("41",QuizItem())
            put("2234",QuizItem(level = LevelEnum.HARD))
        }
    }

    private fun setUpRecyclerView() {

        quest_item_list.layoutManager = GridLayoutManager(context, COLUMN_COUNT)
        quest_item_list.adapter = QuizChooserRecyclerViewAdapter(quizzesMap, onStartQuizListener)


    }
    interface OnStartQuizListener{
        fun onStartQuizSelected(quiz: QuizItem,string:String)
    }
    companion object {
        private const val COLUMN_COUNT = 3
    }

}