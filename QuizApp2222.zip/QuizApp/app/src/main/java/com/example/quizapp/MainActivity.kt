package com.example.quizapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.example.quizapp.R.id.navigation
import com.example.quizapp.R.id.viewpager
import com.google.android.material.bottomnavigation.BottomNavigationView

import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.navigation
import kotlinx.android.synthetic.main.activity_main.viewpager


// Główna aktywność app. ViewPager - obsługa gestami i BottomNavigationViewe

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setViewPager()

    }
    //region Ustawienia vPager i BotNav

    private fun setViewPager() {
        val viewPager: ViewPager = findViewById(R.id.viewpager)
        val navigacja: BottomNavigationView = findViewById(R.id.navigation)
        viewPager.adapter = getFragmentPagerAdapter()
        navigacja.setOnNavigationItemSelectedListener(getBottomNavigationItemSelectedListener())
        viewPager.addOnPageChangeListener(getOnPageChangeListener())
        viewPager.offscreenPageLimit = 2

    }
    //endregion
    private fun getOnPageChangeListener() =
        object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {

            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {

                var navigacja: BottomNavigationView = findViewById(R.id.navigation)
                navigacja.menu.getItem(position).isChecked = true
            }

        }

    private fun getBottomNavigationItemSelectedListener() =


        BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when(item.itemId){


            R.id.navigation_home -> {
                val view: ViewPager = findViewById(R.id.viewpager)
                view.currentItem = 0
                return@OnNavigationItemSelectedListener true
            }

                R.id.navigation_dashboard -> {
                    val view: ViewPager = findViewById(R.id.viewpager)
                    view.currentItem = 1
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_notifications -> {
                    val view: ViewPager = findViewById(R.id.viewpager)
                    view.currentItem = 2
                    return@OnNavigationItemSelectedListener true
                }
                else -> return@OnNavigationItemSelectedListener false
        }
        }



    private fun getFragmentPagerAdapter() =
        object: FragmentPagerAdapter(supportFragmentManager){
            override fun getItem(position: Int) = when (position){
                FEED_ID -> Fragment()
                CHOOSER_ID ->  Fragment()
                PROFILE_ID -> Fragment()

                else ->{
                    Log.wtf("Fragment out of bounds","How Came!?")
                    Fragment()
                }
            }

            override fun getCount() = 3



        }

companion object{
    const val FEED_ID = 0
    const val CHOOSER_ID = 1
    const val PROFILE_ID = 2
}
}
