package com.example.quizapp.chooser

import androidx.recyclerview.widget.RecyclerView

class QuizChooserRecyclerViewAdapter: RecyclerView.Adapter<QuizChooserRecyclerViewAdapter.ViewHolder> {
    class ViewHolder(val mView:View): RecyclerView.ViewHolder(mView)
}